import { makeDemoCandles, validateCandles, candlesFromTwelve, getInstrument, instruments } from '../../src/market.js';
import { analyze, explainFallback } from '../../src/analysis.js';

const json=(value,status=200)=>new Response(JSON.stringify(value),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}});
const intervals={'1h':'1h','4h':'4h','1d':'1day','1w':'1week'};
async function requestJSON(req,limit=500000){const raw=await req.text();if(raw.length>limit)throw new Error('Request terlalu besar');try{return JSON.parse(raw||'{}')}catch{throw new Error('Format JSON tidak valid')}}
async function fetchSafe(url,options={}) {const ctl=new AbortController();const timer=setTimeout(()=>ctl.abort(),9000);try{return await fetch(url,{...options,signal:ctl.signal})}finally{clearTimeout(timer)}}
async function twelveCandles(asset,tf){
 const key=process.env.TWELVE_DATA_API_KEY;if(!key)throw Error('TWELVE_DATA_API_KEY belum diatur');
 const url=new URL('https://api.twelvedata.com/time_series');for(const [k,v] of Object.entries({symbol:asset.providerSymbol,interval:intervals[tf],outputsize:'320',apikey:key,format:'JSON'}))url.searchParams.set(k,v);
 const res=await fetchSafe(url);if(!res.ok)throw Error(`Twelve Data HTTP ${res.status}`);const data=await res.json();if(data.status==='error'||!Array.isArray(data.values))throw Error(data.message||'Data candle tidak tersedia');return candlesFromTwelve(data.values,tf);
}
async function cryptoCandles(asset,tf){
 if(tf!=='1d')throw Error('CoinGecko public OHLC hanya digunakan untuk timeframe 1D');
 const r=await fetchSafe(`https://api.coingecko.com/api/v3/coins/${encodeURIComponent(asset.coinId)}/ohlc?vs_currency=usd&days=30`,{headers:{accept:'application/json'}});
 if(!r.ok)throw Error(`CoinGecko HTTP ${r.status}`);const rows=await r.json();if(!Array.isArray(rows))throw Error('Format data CoinGecko tidak valid');
 const bins=new Map();for(const x of rows){const day=Math.floor(Number(x[0])/86400000)*86400;const next={time:day,open:Number(x[1]),high:Number(x[2]),low:Number(x[3]),close:Number(x[4]),volume:null};const old=bins.get(day);if(!old)bins.set(day,next);else{old.high=Math.max(old.high,next.high);old.low=Math.min(old.low,next.low);old.close=next.close}}
 return validateCandles([...bins.values()]);
}
async function fundamentals(asset){
 if(asset.type==='crypto'){
  try{const url=`https://api.coingecko.com/api/v3/coins/${encodeURIComponent(asset.coinId)}?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false&sparkline=false`;const r=await fetchSafe(url);if(!r.ok)throw Error(`CoinGecko HTTP ${r.status}`);const data=await r.json(),m=data.market_data||{};const metrics=[{label:'Market capitalization',value:m.market_cap?.usd,unit:'USD'},{label:'Circulating supply',value:m.circulating_supply,unit:asset.symbol.split('/')[0]},{label:'Total supply',value:m.total_supply,unit:asset.symbol.split('/')[0]},{label:'24h volume',value:m.total_volume?.usd,unit:'USD'}].filter(v=>Number.isFinite(v.value));return {status:metrics.length?'available':'unavailable',source:'CoinGecko',updatedAt:m.last_updated||null,metrics,message:'Market metrics only; not equivalent to full on-chain analysis.'}}
  catch(e){return {status:'unavailable',source:'CoinGecko',metrics:[],message:`Data fundamental crypto tidak tersedia: ${e.message}`}}
 }
 if(asset.type==='stocks'&&process.env.ALPHA_VANTAGE_API_KEY){
  try{const u=new URL('https://www.alphavantage.co/query');u.searchParams.set('function','OVERVIEW');u.searchParams.set('symbol',asset.symbol);u.searchParams.set('apikey',process.env.ALPHA_VANTAGE_API_KEY);const r=await fetchSafe(u);if(!r.ok)throw Error(`Alpha Vantage HTTP ${r.status}`);const v=await r.json();const fields=[['Market capitalization','MarketCapitalization','USD'],['P/E ratio','PERatio','x'],['Profit margin','ProfitMargin','ratio'],['Return on equity','ReturnOnEquityTTM','ratio']];const metrics=fields.map(([label,key,unit])=>({label,value:Number(v[key]),unit})).filter(x=>Number.isFinite(x.value)&&x.value!==0);return {status:metrics.length?'available':'unavailable',source:'Alpha Vantage',updatedAt:null,metrics,message:'Company overview; confirm fiscal period and date before historical research.'}}
  catch(e){return {status:'unavailable',source:'Alpha Vantage',metrics:[],message:`Fundamental saham tidak tersedia: ${e.message}`}}
 }
 return {status:'not_connected',source:null,metrics:[],message:asset.type==='forex'?'Fundamental forex memerlukan data ekonomi dari kedua mata uang; belum tersedia dalam MVP.':'Atur ALPHA_VANTAGE_API_KEY untuk ringkasan perusahaan.'};
}
export default async function handler(req){
 try{
  const url=new URL(req.url), route=url.pathname.split('/').filter(Boolean).at(-1);
  // Block cross-origin browser calls; this is not authentication or persistent rate limiting.
  const origin=req.headers.get('origin');if(origin&&new URL(origin).origin!==url.origin)return json({error:'Origin tidak diizinkan'},403);
  if(req.method==='GET'&&route==='health')return json({ok:true,service:'AXIOM Netlify API',demo:true});
  if(req.method==='GET'&&route==='instruments')return json({instruments});
  if(req.method==='GET'&&route==='candles'){
   const id=url.searchParams.get('id')||'BTCUSD',tf=url.searchParams.get('tf')||'1d',mode=url.searchParams.get('mode')||'demo',asset=getInstrument(id);
   if(!asset||!intervals[tf])return json({error:'Instrumen atau timeframe tidak valid'},400);
   let candles,source='Simulated demonstration',warning='Data simulasi; bukan harga pasar aktual.';
   if(mode==='demo')candles=makeDemoCandles(id,tf);
   else if(mode==='live'){
    try{if(asset.type==='crypto'&&!process.env.TWELVE_DATA_API_KEY){candles=await cryptoCandles(asset,tf);source='CoinGecko';warning='Histori crypto gratis pendek; indikator berperiode panjang mungkin tidak tersedia.'}else{candles=await twelveCandles(asset,tf);source='Twelve Data';warning=null}}
    catch(e){return json({error:`Data aktual tidak tersedia: ${e.message}`,hint:'Gunakan mode DEMO atau periksa API key gratis. Tidak ada fallback diam-diam.'},503)}
   }else return json({error:'Mode hanya demo atau live'},400);
   return json({id,tf,mode,source,warning,updatedAt:new Date().toISOString(),candles});
  }
  if(req.method==='GET'&&route==='fundamentals'){
   const id=url.searchParams.get('id')||'BTCUSD',mode=url.searchParams.get('mode')||'demo',asset=getInstrument(id);
   if(!asset)return json({error:'Instrumen tidak dikenal'},400);
   if(mode==='demo')return json({status:'not_connected',source:'Demo mode',metrics:[],message:'Tidak menampilkan fundamental palsu pada mode simulasi.'});
   if(mode!=='live')return json({error:'Mode tidak valid'},400);
   return json(await fundamentals(asset));
  }
  if(req.method==='POST'&&route==='analyze'){
   const d=await requestJSON(req);if(!getInstrument(d.id)||!Array.isArray(d.candles)||d.candles.length>2000)return json({error:'Input analisis tidak valid'},400);
   const candles=validateCandles(d.candles);if(candles.length<20)return json({error:'Minimal 20 candle diperlukan'},400);
   return json({...analyze(candles),id:d.id,source:typeof d.source==='string'?d.source.slice(0,80):'Unspecified',asOf:new Date().toISOString()});
  }
  if(req.method==='POST'&&route==='explain'){
   const d=await requestJSON(req,16000),asset=getInstrument(d.id);if(!asset||!d.analysis||typeof d.analysis!=='object')return json({error:'Input penjelasan tidak valid'},400);
   const a=d.analysis,evidence={symbol:asset.symbol,type:asset.type,mode:d.mode==='live'?'live':'demo',timeframe:['1h','4h','1d','1w'].includes(d.timeframe)?d.timeframe:'1d',trend:String(a.trend||'unknown').slice(0,50),rsi:Number.isFinite(a.rsi)?a.rsi:null,atrPct:Number.isFinite(a.atrPct)?a.atrPct:null,close:Number.isFinite(a.close)?a.close:null,support:Array.isArray(a.support)?a.support.slice(0,3).map(x=>({price:Number(x.price),touches:Number(x.touches)})):[],resistance:Array.isArray(a.resistance)?a.resistance.slice(0,3).map(x=>({price:Number(x.price),touches:Number(x.touches)})):[],fundamental:'Data fundamental terverifikasi belum dimasukkan dalam payload penjelasan.'};
   const fallback=explainFallback(evidence);
   if(!process.env.GEMINI_API_KEY)return json({provider:'Local rules (no AI API key)',text:fallback,notice:'Penjelasan berbasis aturan, bukan AI generatif.'});
   const model=process.env.GEMINI_MODEL||'gemini-2.5-flash';if(!/^[a-zA-Z0-9._-]+$/.test(model))return json({error:'Model AI tidak valid'},400);
   const prompt=`Anda analis data pasar edukatif. Gunakan HANYA bukti JSON berikut; jangan menambah angka, berita, probabilitas, atau target harga. Jelaskan ketidakpastian dan bahwa mode demo adalah simulasi. Jangan memberikan perintah beli/jual. Tulis 4 paragraf Bahasa Indonesia: ringkasan, teknikal/SR, skenario, keterbatasan.\n${JSON.stringify(evidence)}`;
   try{const r=await fetchSafe(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':process.env.GEMINI_API_KEY},body:JSON.stringify({contents:[{role:'user',parts:[{text:prompt}]}],generationConfig:{temperature:0.15,maxOutputTokens:700}})});if(!r.ok)throw Error(`Gemini HTTP ${r.status}`);const v=await r.json(),output=v.candidates?.[0]?.content?.parts?.map(p=>p.text||'').join('\n').trim();if(!output)throw Error('Respons AI kosong');return json({provider:'Gemini API',text:output,notice:'Interpretasi AI perlu ditinjau; tidak boleh digunakan sebagai keputusan otomatis.'})}
   catch(e){return json({provider:'Local rules (AI unavailable)',text:fallback,notice:`AI tidak tersedia: ${e.message}`})}
  }
  return json({error:'Endpoint tidak ditemukan'},404);
 }catch(e){return json({error:'Request gagal',detail:String(e.message).slice(0,160)},400)}
}

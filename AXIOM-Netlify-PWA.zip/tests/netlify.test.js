import test from 'node:test';
import assert from 'node:assert/strict';
import handler from '../netlify/functions/api.mjs';

function req(route, options={}) { return new Request(`https://axiom-test.netlify.app/.netlify/functions/api/${route}`,options); }

test('Netlify health responds', async()=>{
 const r=await handler(req('health'));
 assert.equal(r.status,200);
 assert.equal((await r.json()).ok,true);
});

test('Netlify returns instrument catalog', async()=>{
 const r=await handler(req('instruments'));
 assert.equal(r.status,200);
 assert.equal((await r.json()).instruments.length,9);
});

test('Netlify demo candles and analyze', async()=>{
 const r=await handler(req('candles?id=BTCUSD&tf=1d&mode=demo'));
 assert.equal(r.status,200);
 const candle=await r.json();
 assert.equal(candle.candles.length,260);
 const analysis=await handler(req('analyze',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({id:'BTCUSD',candles:candle.candles,source:candle.source})}));
 assert.equal(analysis.status,200);
 const result=await analysis.json();
 assert.ok(result.trend);
});

test('Netlify fallback explanatory report without AI key',async()=>{
 const r=await handler(req('explain',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({id:'EURUSD',analysis:{trend:'mixed',close:1.1,support:[],resistance:[]},mode:'demo',timeframe:'1d'})}));
 assert.equal(r.status,200);
 const data=await r.json();assert.match(data.provider,/Local rules/);
});

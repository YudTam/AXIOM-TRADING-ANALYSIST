const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const state={assets:[],id:'BTCUSD',tf:'1d',mode:'demo',cat:'all',candles:[],analysis:null,busy:false};
const api=async(path,opts)=>{const r=await fetch(path,opts);const v=await r.json();if(!r.ok)throw Error(v.error||`HTTP ${r.status}`);return v};
const fmt=(n,d=2)=>n==null||!Number.isFinite(n)?'—':Number(n).toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d});
const fmtPrice=n=>n==null?'—':Number(n)<5?fmt(n,5):Number(n)<200?fmt(n,3):fmt(n,2);
const toast=(msg)=>{const t=$('#toast');t.textContent=msg;t.classList.remove('hidden');clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>t.classList.add('hidden'),4800)};
const asset=()=>state.assets.find(a=>a.id===state.id);
const emoji={crypto:'₿',forex:'≋',stocks:'▥'};
function initWatchlist(){const container=$('#watchlist');container.innerHTML='';const list=state.cat==='all'?state.assets:state.assets.filter(a=>a.type===state.cat);
 // Keep UI compact: first 6 cards when showing all, with all instruments available via dropdown.
 for(const a of (state.cat==='all'?list.filter(x=>['BTCUSD','ETHUSD','EURUSD','GBPUSD','AAPL','MSFT'].includes(x.id)):list)){
  const b=document.createElement('button');b.className='watchcard'+(state.id===a.id?' selected':'');
  const icon=emoji[a.type]; const colors={crypto:'#e9b56b',forex:'#9ab9fa',stocks:'#c4adf9'};
  b.innerHTML=`<div class="watchcard-top"><span class="watch-icon" style="color:${colors[a.type]}">${icon}</span><div><div class="watch-name">${a.symbol}</div><div class="watch-sub">${a.name}</div></div><span class="arrow">↗</span></div><div class="watchcard-bottom"><div class="watchprice" id="watch-${a.id}">VIEW CHART</div><span class="watchchange">${a.type.toUpperCase()}</span></div>`;
  b.addEventListener('click',()=>selectAsset(a.id));container.appendChild(b);
 }
}
async function selectAsset(id){state.id=id;initWatchlist();$('#asset-dropdown').classList.add('hidden');await load();}
async function load(){if(state.busy)return;state.busy=true;$('#refresh').textContent='◌';const a=asset();$('#asset-name').textContent=a.symbol;$('#asset-sub').textContent=`${a.name} · ${a.type.toUpperCase()}`;$('#asset-badge').textContent=emoji[a.type];$('#asset-badge').style.background=a.type==='forex'?'#233853':a.type==='stocks'?'#3c2d55':'#3e3524';
 try{
  const response=await api(`/api/candles?id=${encodeURIComponent(state.id)}&tf=${encodeURIComponent(state.tf)}&mode=${state.mode}`);
  const analysis=await api('/api/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:state.id,candles:response.candles,source:response.source})});
  state.candles=response.candles;state.analysis=analysis;
  $('#data-source').textContent=`SOURCE: ${response.source.toUpperCase()}`;
  $('#mode-notice').querySelector('span:nth-child(2)').textContent=response.warning||`Data eksternal: ${response.source}. Pastikan timestamp dan cakupan provider sesuai kebutuhan analisis.`;
  $('#last-price').textContent=fmtPrice(analysis.close);$('#price-change').textContent=`${analysis.change>=0?'+':''}${fmt(analysis.change)}% last candle`;$('#price-change').className=analysis.change>=0?'positive':'negative';
  $('#price-asof').textContent=new Date(state.candles.at(-1).time*1000).toLocaleDateString('id-ID',{day:'numeric',month:'short',year:'numeric'});
  $('#trend-status').textContent=analysis.trend==='bullish'?'BULLISH TREND':analysis.trend==='bearish'?'BEARISH TREND':analysis.trend==='mixed'?'MIXED / TRANSITION':'INSUFFICIENT DATA';$('#trend-status').style.color=analysis.trend==='bullish'?'#a4e2a7':analysis.trend==='bearish'?'#ff99a9':'#e7c98f';
  $('#rsi').textContent=fmt(analysis.rsi,1);$('#macd').textContent=fmt(analysis.macdHistogram,5);$('#atr').textContent=analysis.atrPct==null?'—':`${fmt(analysis.atrPct)}%`;$('#ema').textContent=`${fmtPrice(analysis.ema50)} / ${fmtPrice(analysis.ema200)}`;
  const sup=analysis.support[0],res=analysis.resistance[0];$('#support-price').textContent=sup?fmtPrice(sup.price):'N/A';$('#support-touches').textContent=sup?`${sup.touches} pivot(s) · ±${fmtPrice(sup.width)}`:'Not enough confirmed pivots';$('#resistance-price').textContent=res?fmtPrice(res.price):'N/A';$('#resistance-touches').textContent=res?`${res.touches} pivot(s) · ±${fmtPrice(res.width)}`:'Not enough confirmed pivots';
  $('#bull-case').textContent=analysis.scenarios.bullish;$('#bear-case').textContent=analysis.scenarios.bearish;$('#side-case').textContent=analysis.scenarios.sideways;$('#fundamentals-status').textContent='NOT CONNECTED';
  $('#ai-report').textContent='Ringkasan teknikal siap. Tekan “Generate Insight” untuk penjelasan berdasarkan data terukur. Tanpa API key AI, aplikasi tetap menyediakan narasi lokal berbasis aturan.';
  $('#ai-provider').textContent='READY';$('#ai-notice').textContent=`${response.candles.length} candles · ${response.source}`;
  drawChart();
  // Fetch independent fundamental data only in live mode, with transparent availability.
  $('#fundamental-metrics').replaceChildren();$('#fundamentals-status').textContent='CHECKING';
  if(state.mode==='live'){
    api(`/api/fundamentals?id=${encodeURIComponent(state.id)}&mode=live`).then(f=>{
      if(state.id!==a.id)return;
      $('#fundamentals-status').textContent=f.status==='available'?'DATA AVAILABLE':'NOT CONNECTED';
      $('#fundamental-details').textContent=f.message+(f.source?` · Source: ${f.source}`:'');
      for(const m of (f.metrics||[])){
       const item=document.createElement('div'),key=document.createElement('span'),value=document.createElement('b');key.textContent=m.label;
       value.textContent=m.unit==='ratio'?`${fmt(m.value*100,2)}%`:m.unit==='USD'?`$${fmt(m.value,0)}`:`${fmt(m.value,2)} ${m.unit}`;
       item.append(key,value);$('#fundamental-metrics').append(item);
      }
    }).catch(e=>{$('#fundamentals-status').textContent='UNAVAILABLE';$('#fundamental-details').textContent=e.message;});
  }else{$('#fundamentals-status').textContent='DEMO ONLY';$('#fundamental-details').textContent='Mode demo tidak menyajikan angka fundamental fiktif.';}

  const watch=$(`#watch-${a.id}`);if(watch)watch.textContent=fmtPrice(analysis.close);
  if(response.warning&&state.mode==='live')toast(response.warning);
 }catch(e){toast(e.message);$('#data-source').textContent='DATA UNAVAILABLE';$('#ai-report').textContent='Gagal memuat data. Data aktual tidak akan diganti demo secara diam-diam. Pilih DEMO jika ingin mencoba aplikasi tanpa API key.';}finally{state.busy=false;$('#refresh').textContent='↻';}}
function ema(vals,p){if(vals.length<p)return [];const a=Array(vals.length).fill(null);let s=0;for(let i=0;i<p;i++)s+=vals[i];a[p-1]=s/p;const k=2/(p+1);for(let i=p;i<vals.length;i++)a[i]=a[i-1]*(1-k)+vals[i]*k;return a}
const svgEl=(name,attrs={})=>{const n=document.createElementNS('http://www.w3.org/2000/svg',name);for(const [k,v] of Object.entries(attrs))n.setAttribute(k,v);return n};
function drawChart(){
 const svg=$('#chart'),full=state.candles,analysis=state.analysis;if(!full.length)return;svg.replaceChildren();
 const values=full.slice(-88),W=820,H=365,P={l:13,r:83,t:15,b:24},gW=W-P.l-P.r,gH=H-P.t-P.b;
 const allHigh=values.map(c=>c.high),allLow=values.map(c=>c.low);for(const z of [...analysis.support,...analysis.resistance])if(z.price>0){allHigh.push(z.price+z.width);allLow.push(z.price-z.width)}
 let lo=Math.min(...allLow),hi=Math.max(...allHigh);const pad=(hi-lo)*.085;lo-=pad;hi+=pad;
 const y=n=>P.t+(hi-n)/(hi-lo)*gH,x=i=>P.l+i/(values.length-1)*gW,ns='http://www.w3.org/2000/svg';
 for(let i=0;i<6;i++){const yy=P.t+(gH*i/5),price=hi-(hi-lo)*i/5;svg.append(svgEl('line',{x1:P.l,y1:yy,x2:W-P.r+5,y2:yy,stroke:'#2a3848','stroke-dasharray':'3 5','stroke-width':'1'}));const t=svgEl('text',{x:W-P.r+11,y:yy+4,fill:'#72869a','font-size':11});t.textContent=fmtPrice(price);svg.append(t)}
 const zone=(items,color)=>{for(const z of items.slice(0,2)){const yy=y(z.price),th=Math.max(3,Math.abs(y(z.price+z.width)-y(z.price-z.width)));svg.append(svgEl('rect',{x:P.l,y:yy-th/2,width:gW,height:th,fill:color,'fill-opacity':'.105'}));svg.append(svgEl('line',{x1:P.l,y1:yy,x2:W-P.r,y2:yy,stroke:color,'stroke-dasharray':'5 4','stroke-width':'1.2','stroke-opacity':'.8'}));}};
 zone(analysis.support,'#55c8a0');zone(analysis.resistance,'#f28b99');
 const closes=full.map(a=>a.close);for(const [p,color] of [[20,'#7aacf7'],[50,'#f9be69'],[200,'#a084f4']]){
  const series=ema(closes,p);let d='';for(let i=0;i<values.length;i++){const idx=full.length-values.length+i;if(series[idx]!==null&&series[idx]!==undefined)d+=(d?' L':'M')+`${x(i).toFixed(2)} ${y(series[idx]).toFixed(2)}`}
  if(d)svg.append(svgEl('path',{d,stroke:color,'stroke-width':1.5,fill:'none','stroke-opacity':'.82'}));
 }
 const barWidth=Math.max(3,Math.min(8,gW/values.length*.64));
 values.forEach((c,i)=>{const xx=x(i),up=c.close>=c.open,color=up?'#5bd7b3':'#ef8291';svg.append(svgEl('line',{x1:xx,y1:y(c.high),x2:xx,y2:y(c.low),stroke:color,'stroke-width':1.2}));svg.append(svgEl('rect',{x:xx-barWidth/2,y:Math.min(y(c.open),y(c.close)),width:barWidth,height:Math.max(1.3,Math.abs(y(c.open)-y(c.close))),fill:color,rx:'.4'}))});
 for(const [i,t] of [[0,values[0].time],[Math.floor((values.length-1)/2),values[Math.floor((values.length-1)/2)].time],[values.length-1,values.at(-1).time]]){const txt=svgEl('text',{x:x(i),y:H-5,fill:'#73859a','font-size':10,'text-anchor':i===0?'start':i===values.length-1?'end':'middle'});txt.textContent=new Date(t*1000).toLocaleDateString('en-US',{month:'short',day:'numeric'});svg.append(txt)}
 const vertical=svgEl('line',{x1:0,x2:0,y1:P.t,y2:H-P.b,stroke:'#8a9faf','stroke-dasharray':'3 4','stroke-opacity':'.7',visibility:'hidden'});svg.append(vertical);
 const hover=evt=>{const rect=svg.getBoundingClientRect(),at=(evt.clientX-rect.left)/rect.width*W,i=Math.max(0,Math.min(values.length-1,Math.round((at-P.l)/gW*(values.length-1)))),c=values[i];vertical.setAttribute('x1',x(i));vertical.setAttribute('x2',x(i));vertical.setAttribute('visibility','visible');const tip=$('#chart-tooltip');tip.textContent=`${new Date(c.time*1000).toLocaleString('id-ID',{dateStyle:'medium'})}\nO ${fmtPrice(c.open)}    H ${fmtPrice(c.high)}\nL ${fmtPrice(c.low)}    C ${fmtPrice(c.close)}`;tip.classList.remove('hidden');tip.style.left=`${Math.min(Math.max(8,evt.clientX-rect.left+12),rect.width-165)}px`;tip.style.top=`${Math.max(12,evt.clientY-rect.top-53)}px`};
 svg.onmousemove=hover;svg.onmouseleave=()=>{vertical.setAttribute('visibility','hidden');$('#chart-tooltip').classList.add('hidden')};
}
async function explain(){if(!state.analysis)return;const btn=$('#explain-btn');btn.disabled=true;btn.textContent='Generating...';try{const r=await api('/api/explain',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:state.id,timeframe:state.tf,mode:state.mode,analysis:state.analysis})});$('#ai-provider').textContent=r.provider.toUpperCase().slice(0,20);$('#ai-report').textContent=r.text;$('#ai-notice').textContent=r.notice;}catch(e){toast(e.message)}finally{btn.disabled=false;btn.innerHTML='✧ Generate Insight <span>→</span>'}}
function handlers(){ $$('#categories button').forEach(b=>b.addEventListener('click',()=>{state.cat=b.dataset.cat;$$('#categories button').forEach(x=>x.classList.toggle('selected',x===b));initWatchlist()})); $$('.asset-link').forEach(b=>b.addEventListener('click',()=>{state.cat=b.dataset.category;$$('#categories button').forEach(x=>x.classList.toggle('selected',x.dataset.cat===state.cat));initWatchlist();$('#mobile-menu').click()}));$$('.tf-group button').forEach(b=>b.addEventListener('click',()=>{if(state.busy)return;state.tf=b.dataset.tf;$$('.tf-group button').forEach(x=>x.classList.toggle('selected',x===b));load()}));$('#data-mode').addEventListener('change',e=>{state.mode=e.target.value;load()});$('#refresh').addEventListener('click',load);$('#explain-btn').addEventListener('click',explain);$('#asset-select-toggle').addEventListener('click',()=>$('#asset-dropdown').classList.toggle('hidden'));$('#mobile-menu').addEventListener('click',()=>$('.sidebar').classList.toggle('open'));$('#dismiss-notice').onclick=()=>$('#mode-notice').classList.add('hidden');$('#info-btn').onclick=()=>$('#modal').classList.remove('hidden');$('#modal-close').onclick=()=>$('#modal').classList.add('hidden');$('#modal').onclick=e=>{if(e.target.id==='modal')$('#modal').classList.add('hidden')};$('#asset-dropdown').addEventListener('click',e=>{const item=e.target.closest('[data-asset]');if(item)selectAsset(item.dataset.asset)});}
async function init(){handlers();$('#clock').textContent=new Date().toLocaleDateString('en-US',{day:'2-digit',month:'short',year:'numeric'});try{state.assets=(await api('/api/instruments')).instruments;$('#asset-dropdown').innerHTML=state.assets.map(a=>`<button class="asset-option" data-asset="${a.id}">${a.symbol} · ${a.name}</button>`).join('');initWatchlist();await load()}catch(e){toast(e.message)}}init();

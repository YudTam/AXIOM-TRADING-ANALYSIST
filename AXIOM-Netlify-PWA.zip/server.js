import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { makeDemoCandles, validateCandles, candlesFromTwelve, getInstrument, instruments } from './src/market.js';
import { analyze, explainFallback } from './src/analysis.js';

const root = path.dirname(fileURLToPath(import.meta.url));
try { const data = await fs.readFile(path.join(root, '.env'), 'utf8'); for (const line of data.split(/\r?\n/)) { const m = /^([A-Z_]+)=(.*)$/.exec(line.trim()); if(m && !process.env[m[1]]) process.env[m[1]]=m[2].replace(/^['"]|['"]$/g,''); } } catch {}
const port = Number(process.env.PORT || 3000);
const send=(res,status,value,headers={})=>{res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers});res.end(JSON.stringify(value));};
const counter = new Map();
function rateLimit(req) { const ip=req.socket.remoteAddress || 'unknown', now=Date.now(), x=counter.get(ip)||{n:0,t:now}; if(now-x.t>60000){x.n=0;x.t=now} x.n++;counter.set(ip,x);return x.n<=50; }
async function readJSON(req, limit=30000) {let data=''; for await(const chunk of req){data+=chunk;if(data.length>limit)throw new Error('Request terlalu besar');}return JSON.parse(data||'{}');}
const fetchWithTimeout=async (url, opts={})=>{const controller=new AbortController(), t=setTimeout(()=>controller.abort(),9500);try{return await fetch(url,{...opts,signal:controller.signal});}finally{clearTimeout(t)}};
const twelveInterval={ '1h':'1h', '4h':'4h','1d':'1day','1w':'1week' };
async function fetchTwelve(asset,tf){
 const apiKey=process.env.TWELVE_DATA_API_KEY; if(!apiKey)throw new Error('Twelve Data API key belum diatur');
 const url=new URL('https://api.twelvedata.com/time_series');url.searchParams.set('symbol',asset.providerSymbol);url.searchParams.set('interval',twelveInterval[tf]);url.searchParams.set('outputsize','320');url.searchParams.set('apikey',apiKey);url.searchParams.set('format','JSON');
 const response=await fetchWithTimeout(url);if(!response.ok)throw Error(`Twelve Data HTTP ${response.status}`);const data=await response.json();if(data.status==='error'||!Array.isArray(data.values))throw Error(data.message||'Data candle tidak tersedia');return candlesFromTwelve(data.values,tf);
}
async function fetchCoinGecko(asset,tf){
 // CoinGecko public market_chart is approximate for intraday sampling; use daily only to avoid inventing candles.
 if(tf!=='1d')throw Error('CoinGecko public API hanya dipakai untuk 1D pada MVP ini');
 const url=`https://api.coingecko.com/api/v3/coins/${encodeURIComponent(asset.coinId)}/ohlc?vs_currency=usd&days=30`;
 const response=await fetchWithTimeout(url,{headers:{'accept':'application/json'}});if(!response.ok)throw Error(`CoinGecko HTTP ${response.status}`);
 const data=await response.json();if(!Array.isArray(data))throw Error('Format CoinGecko tidak valid');
 // Aggregate provider OHLC bars into UTC calendar days (never pretend 4h bars are daily bars).
 const bins=new Map();for(const x of data){const day=Math.floor(Number(x[0])/86400000)*86400;const next={time:day,open:Number(x[1]),high:Number(x[2]),low:Number(x[3]),close:Number(x[4]),volume:null};const old=bins.get(day);if(!old)bins.set(day,next);else{old.high=Math.max(old.high,next.high);old.low=Math.min(old.low,next.low);old.close=next.close;}}return validateCandles([...bins.values()]);
}
function requestIsLocal(req){const o=req.headers.origin;if(!o)return true;try{return new URL(o).host===req.headers.host}catch{return false}}
const server=http.createServer(async(req,res)=>{
 try{
  const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
  if(url.pathname.startsWith('/api/')){
   if(!rateLimit(req))return send(res,429,{error:'Batas permintaan lokal. Coba lagi setelah 1 menit.'});
   if(!requestIsLocal(req))return send(res,403,{error:'Origin tidak diizinkan'});
   if(req.method==='GET'&&url.pathname==='/api/health')return send(res,200,{ok:true,service:'Market Intelligence Terminal',demo:true});
   if(req.method==='GET'&&url.pathname==='/api/instruments')return send(res,200,{instruments});
   if(req.method==='GET'&&url.pathname==='/api/candles'){
    const id=url.searchParams.get('id')||'BTCUSD',tf=url.searchParams.get('tf')||'1d',mode=url.searchParams.get('mode')||'demo',asset=getInstrument(id);
    if(!asset||!twelveInterval[tf])return send(res,400,{error:'Instrumen atau timeframe tidak valid'});
    let candles,origin='Simulated demonstration',warning='Data simulasi untuk pengujian antarmuka; bukan data pasar aktual.';
    if(mode==='live'){
      try{
        candles=asset.type==='crypto'&&!process.env.TWELVE_DATA_API_KEY?await fetchCoinGecko(asset,tf):await fetchTwelve(asset,tf);
        origin=asset.type==='crypto'&&!process.env.TWELVE_DATA_API_KEY?'CoinGecko':'Twelve Data'; warning=origin==='CoinGecko'?'Candle CoinGecko telah digabung per hari UTC dari interval yang disediakan API. Histori 30 hari belum cukup untuk EMA50/EMA200 dan klasifikasi tren panjang.':null;
      }catch(e){return send(res,503,{error:`Data aktual tidak tersedia: ${e.message}`,hint:'Pilih mode DEMO atau isi API key di file .env. Sistem tidak mengganti data aktual dengan data simulasi secara diam-diam.'});}
    }else if(mode==='demo')candles=makeDemoCandles(id,tf);
    else return send(res,400,{error:'Mode hanya demo atau live'});
    return send(res,200,{id,tf,mode,source:origin,warning,updatedAt:new Date().toISOString(),candles});
   }
   if(req.method==='GET'&&url.pathname==='/api/fundamentals'){
    const id=url.searchParams.get('id')||'BTCUSD',mode=url.searchParams.get('mode')||'demo',asset=getInstrument(id);
    if(!asset)return send(res,400,{error:'Instrumen tidak dikenal'});
    if(mode!=='live')return send(res,200,{status:'not_connected',source:'Demo mode',metrics:[],message:'Tidak menampilkan fundamental palsu pada mode simulasi.'});
    if(asset.type==='crypto'){
      try{
        const endpoint=`https://api.coingecko.com/api/v3/coins/${encodeURIComponent(asset.coinId)}?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false&sparkline=false`;
        const r=await fetchWithTimeout(endpoint);if(!r.ok)throw Error(`CoinGecko HTTP ${r.status}`);const data=await r.json();const m=data.market_data||{};
        const metrics=[{label:'Market capitalization',value:m.market_cap?.usd,unit:'USD'},{label:'Circulating supply',value:m.circulating_supply,unit:asset.symbol.split('/')[0]},{label:'Total supply',value:m.total_supply,unit:asset.symbol.split('/')[0]},{label:'24h volume',value:m.total_volume?.usd,unit:'USD'}].filter(x=>Number.isFinite(x.value));
        return send(res,200,{status:metrics.length?'available':'unavailable',source:'CoinGecko',updatedAt:m.last_updated||null,metrics,message:'Market metrics only; these are not equivalent to equity valuation or full on-chain analysis.'});
      }catch(e){return send(res,200,{status:'unavailable',source:'CoinGecko',metrics:[],message:`Data crypto fundamental tidak tersedia: ${e.message}`})}
    }
    if(asset.type==='stocks'&&process.env.ALPHA_VANTAGE_API_KEY){
      try{
        const u=new URL('https://www.alphavantage.co/query');u.searchParams.set('function','OVERVIEW');u.searchParams.set('symbol',asset.symbol);u.searchParams.set('apikey',process.env.ALPHA_VANTAGE_API_KEY);
        const r=await fetchWithTimeout(u);if(!r.ok)throw Error(`Alpha Vantage HTTP ${r.status}`);const v=await r.json();const fields=[['Market capitalization','MarketCapitalization','USD'],['P/E ratio','PERatio','x'],['Profit margin','ProfitMargin','ratio'],['Return on equity','ReturnOnEquityTTM','ratio']];const metrics=fields.map(([label,key,unit])=>({label,value:Number(v[key]),unit})).filter(x=>Number.isFinite(x.value)&&x.value!==0);
        return send(res,200,{status:metrics.length?'available':'unavailable',source:'Alpha Vantage',updatedAt:null,metrics,message:'Company overview; verify fiscal periods and timestamps for any historical study.'});
      }catch(e){return send(res,200,{status:'unavailable',source:'Alpha Vantage',metrics:[],message:e.message})}
    }
    return send(res,200,{status:'not_connected',source:null,metrics:[],message:asset.type==='forex'?'Fundamental forex membutuhkan rangkaian indikator ekonomi dari kedua mata uang. Belum tersedia dalam MVP.':'Atur ALPHA_VANTAGE_API_KEY untuk ringkasan perusahaan.'});
   }
   if(req.method==='POST'&&url.pathname==='/api/analyze'){
    const data=await readJSON(req,500000);
    if(!getInstrument(data.id)||!Array.isArray(data.candles)||data.candles.length>2000)return send(res,400,{error:'Input analisis tidak valid'});
    const candles=validateCandles(data.candles);if(candles.length<20)return send(res,400,{error:'Minimal 20 candle diperlukan'});
    const output=analyze(candles);return send(res,200,{...output,id:data.id,source:data.source||'Unspecified',asOf:new Date().toISOString()});
   }
   if(req.method==='POST'&&url.pathname==='/api/explain'){
    const data=await readJSON(req,16000),asset=getInstrument(data.id);
    if(!asset||!data.analysis||typeof data.analysis!=='object')return send(res,400,{error:'Input AI tidak valid'});
    // Reconstruct evidence solely from allowlisted numeric/text fields.
    const a=data.analysis;
    const evidence={symbol:asset.symbol,type:asset.type,mode:data.mode==='live'?'live':'demo',timeframe:String(data.timeframe||'1d'),trend:String(a.trend||'unknown'),rsi:Number.isFinite(a.rsi)?a.rsi:null,atrPct:Number.isFinite(a.atrPct)?a.atrPct:null,close:Number.isFinite(a.close)?a.close:null,support:Array.isArray(a.support)?a.support.slice(0,3).map(x=>({price:Number(x.price),touches:Number(x.touches)})):[],resistance:Array.isArray(a.resistance)?a.resistance.slice(0,3).map(x=>({price:Number(x.price),touches:Number(x.touches)})):[],fundamental:'Data fundamental terverifikasi tidak tersedia di MVP; jangan menarik kesimpulan fundamental.'};
    const local=explainFallback(evidence);
    if(!process.env.GEMINI_API_KEY)return send(res,200,{provider:'Local rules (no AI API key)',text:local,notice:'Penjelasan berbasis aturan; bukan generative AI.'});
    const prompt=`Anda adalah analis data pasar edukatif. HANYA gunakan JSON bukti berikut, jangan menambahkan angka, berita, data makro, probabilitas atau target harga. Nyatakan ketidakpastian, bedakan simulasi dengan data aktual. Tidak memberikan perintah beli/jual. Tulis Bahasa Indonesia dengan 4 paragraf pendek: Ringkasan, Teknikal & Support Resistance, Skenario, Keterbatasan.\n${JSON.stringify(evidence)}`;
    try{
      const model=process.env.GEMINI_MODEL||'gemini-2.5-flash';if(!/^[a-zA-Z0-9._-]+$/.test(model))throw Error('Model tidak valid');
      const response=await fetchWithTimeout(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':process.env.GEMINI_API_KEY},body:JSON.stringify({contents:[{role:'user',parts:[{text:prompt}]}],generationConfig:{temperature:0.15,maxOutputTokens:700}})});
      if(!response.ok)throw Error(`Gemini HTTP ${response.status}`);
      const result=await response.json();const textOut=result.candidates?.[0]?.content?.parts?.map(p=>p.text||'').join('\n').trim();if(!textOut)throw Error('Respons AI kosong');
      return send(res,200,{provider:'Gemini API',text:textOut,notice:'Hasil AI perlu ditinjau; hanya data bukti terstruktur yang diberikan.'});
    }catch(e){return send(res,200,{provider:'Local rules (AI unavailable)',text:local,notice:`AI tidak tersedia: ${e.message}. Menggunakan analisis berbasis aturan.`});}
   }
   return send(res,404,{error:'Endpoint tidak ditemukan'});
  }
  if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405);return res.end('Method not allowed')}
  let pathname=decodeURIComponent(url.pathname);if(pathname==='/')pathname='/index.html';
  const target=path.resolve(root,'public',pathname.replace(/^\/+/,''));if(!target.startsWith(path.join(root,'public')+path.sep)) {res.writeHead(403);return res.end('Forbidden')}
  const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.webmanifest':'application/manifest+json'};
  try{const content=await fs.readFile(target);res.writeHead(200,{'Content-Type':mime[path.extname(target)]||'application/octet-stream','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});res.end(req.method==='HEAD'?'':content)}catch{res.writeHead(404);res.end('Not found')}
 }catch(e){send(res,500,{error:'Server error',detail:String(e.message).slice(0,180)})}
});
server.listen(port,()=>console.log(`Market Intelligence Terminal → http://localhost:${port}`));

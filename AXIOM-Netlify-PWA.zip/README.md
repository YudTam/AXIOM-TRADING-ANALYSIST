# AXIOM — Market Intelligence Terminal (Zero-cost MVP)

Dashboard pasar **forex, saham, crypto** dengan grafik candlestick, **support/resistance** terdeteksi otomatis, EMA 20/50/200, RSI 14, MACD 12/26/9, ATR 14, skenario bullish/bearish/sideways dan penjelasan berbasis aturan atau Gemini AI (opsional).

## Jalankan sekarang

Prasyarat: Node.js >=20. **Tidak membutuhkan npm install, database, registrasi akun, ataupun API key** untuk mode demo.

```bash
node server.js
```

Buka **http://localhost:3000**.

Atau jalankan pengujian:

```bash
npm test
```

## Mode DEMO dan LIVE

**DEMO (default):** 260 candle sintetis yang bisa direproduksi secara konsisten dalam satu interval waktu. Data sepenuhnya fiktif, dan ditandai jelas di UI. Analisis teknikal dihitung sungguhan dari data simulasi tersebut. Mode ini selalu bisa dipakai tanpa jaringan.

**LIVE:** menggunakan API market data:

- Forex / stocks: Twelve Data (butuh `TWELVE_DATA_API_KEY` gratis dan tunduk pada lisensi/kuota).
- Crypto 1D: CoinGecko public OHLC API tanpa API key jika Twelve Data key tidak disetel. Candle dikonsolidasikan berdasarkan tanggal UTC dari data provider; data sekitar 30 hari belum cukup untuk EMA50/EMA200, sehingga tren jangka panjang akan ditandai `insufficient_data`. Timeframe lain akan menghasilkan error yang transparan. (Jika Twelve Data key disetel, ketiga aset menggunakan Twelve Data.)
- API gagal: tampilkan kesalahan. Tidak ada fallback diam-diam ke data simulasi.

Untuk memasang key opsional, buat file `.env` di root berdasarkan `.env.example` lalu jalankan ulang server. **Jangan commit file `.env`.**

```bash
cp .env.example .env
# isi TWELVE_DATA_API_KEY jika diperlukan
# isi GEMINI_API_KEY jika ingin penjelasan generatif
node server.js
```

**AI:** tanpa Gemini key, tombol `Generate Insight` membuat narasi berbasis aturan lokal; ini **bukan** AI generatif. Dengan Gemini key gratis yang memenuhi syarat, server memanggil API Gemini. Kuota gratis, model, dan ketersediaan dapat berubah.

## Keputusan arsitektur

- **Node.js HTTP server bawaan**: menghindari pemasangan dependency berbayar dan memungkinkan proyek berjalan secara instan/offline.
- **Vanilla JS + CSS + SVG chart**: interaktif, tanpa CDN wajib, tanpa kebutuhan build. Chart tidak menggunakan library berbayar atau widget tertutup.
- **Tanpa database**: histori tidak disimpan permanen dan data dibuat / diminta ulang sesuai mode.
- **API proxy server-side**: key tidak diekspos di frontend.
- **Analisis deterministik**: fungsi terpisah dengan pengujian `node:test`.

## Struktur

```
server.js           Server, API proxy, penjelasan AI opsional
src/market.js       Instrument catalog, provider normalization, demo data
src/analysis.js     EMA, RSI, MACD, ATR, swing pivot + S/R clustering, rules
public/index.html   Dashboard
public/style.css    Dark UI responsive
public/app.js       Interactive chart & UI
AGENTS.md           Codex developer instructions
docs/               PRD ringkas dan roadmap
```

## Batasan yang sengaja dipertahankan

1. **Fundamental hanya terhubung secara parsial**: dalam mode LIVE, metrik pasar crypto dari CoinGecko dapat ditampilkan; untuk ringkasan fundamental saham tersedia API key opsional Alpha Vantage (`ALPHA_VANTAGE_API_KEY`). Fundamental forex belum terhubung, karena membutuhkan data dari kedua negara. Tahap lanjutan adalah FRED dan sumber resmi lainnya.
2. Model S/R memakai pivot kiri/kanan terkonfirmasi dan pengelompokan jarak berbasis ATR. Pendekatan ini **heuristik**, bukan jaminan harga akan berbalik.
3. Klasifikasi tren sederhana: close vs EMA50 vs EMA200. **Tidak ada probabilitas atau jaminan prediksi.**
4. API gratis memiliki kuota, keterbatasan sejarah, kemungkinan penundaan, dan ketentuan publikasi komersial.
5. Jika mengaktifkan LIVE, pastikan sumber data memiliki izin yang sesuai penggunaan Anda.
6. Server dirancang untuk **localhost pribadi**, bukan langsung untuk hosting publik. Sebelum deploy, tambahkan autentikasi, rate limiting persisten, CSRF protection, dan lisensi data yang sesuai.
7. Tidak ada integrasi broker ataupun eksekusi transaksi.

## Langkah berikutnya untuk Codex

Buka folder proyek di Codex. Baca `AGENTS.md`, lalu implementasikan integrasi fundamental yang terverifikasi per asset type dengan ketentuan nol biaya wajib, dan pengujian komprehensif. Jangan mengubah mode demo yang sudah berfungsi.

## Jalankan di iOS / Android (PWA)

Proyek ini sekarang memiliki manifest, icon, service worker, dukungan standalone, dan safe-area mobile. **Tidak membutuhkan App Store atau Play Store**.

**Tes dari HP pada Wi-Fi yang sama:**

1. Jalankan `node server.js` di komputer.
2. Dapatkan IPv4 lokal komputer (Windows `ipconfig`, macOS/Linux `hostname -I` atau pengaturan jaringan).
3. Dari Safari/Chrome di HP, buka `http://IP-KOMPUTER:3000` (bukan `localhost:3000`). Pastikan firewall mengizinkan port 3000 di jaringan privat.
4. Fitur dashboard berfungsi, namun **pemasangan PWA dengan service worker memerlukan HTTPS** (atau `localhost` pada perangkat itu sendiri). Untuk install di Home Screen dengan pengalaman penuh, deploy ke hosting HTTPS yang kompatibel dengan server Node.js, atau gunakan HTTPS tunnel sementara untuk pengujian.

**iPhone / iPad:** buka URL HTTPS di Safari, pilih Share → Add to Home Screen → Add.

**Android:** buka URL HTTPS di Chrome, pilih menu ⋮ → Install app atau Add to Home screen (tergantung browser).

Catatan: PWA bukan IPA/APK native, tidak tersedia lewat App Store/Google Play, dan tetap butuh koneksi ke backend untuk data dan analisis. Static UI dapat dicache, tetapi API tidak dicache untuk menghindari menampilkan data pasar usang. Jangan expose server development ke internet langsung: gunakan hosting dengan pengamanan sebelum digunakan publik.

## Deploy gratis ke Netlify (iOS/Android PWA)

Proyek sekarang mendukung **Netlify Functions** untuk seluruh endpoint `/api/` dan static hosting `public/` lewat `netlify.toml`. Server lokal (`node server.js`) tetap didukung. **Tidak perlu database, build step, atau paket npm eksternal.**

1. Buat akun Netlify Free melalui https://app.netlify.com/.
2. Ekstrak ZIP proyek. Unggah folder proyek ke repo GitHub milik Anda (jangan commit `.env` atau API key).
3. Netlify → **Add new project** → **Import an existing project** → GitHub → pilih repo.
4. Pastikan build command **kosong**, publish directory **`public`**, functions directory **`netlify/functions`** (sudah disetel oleh `netlify.toml`). Deploy.
5. Buka URL `https://nama-situs.netlify.app`. Cek `/api/health` dan coba DEMO.
6. Opsional: Netlify → Project configuration → Environment variables → masukkan `TWELVE_DATA_API_KEY`, `ALPHA_VANTAGE_API_KEY`, atau `GEMINI_API_KEY` dari paket gratis yang berlaku, lalu deploy ulang. **Jangan** menaruh key di frontend atau file publik.
7. Di iPhone: Safari → Share → Add to Home Screen. Android: Chrome → ⋮ → Install app / Add to Home screen.

### Penting untuk gratis dan keamanan

- Netlify Free memiliki batas credits/bandwidth/compute; jika habis, layanan bisa berhenti sampai siklus berikutnya. Jangan upgrade atau memasang billing berbayar jika ingin tetap nol biaya.
- Endpoint AI dapat memicu konsumsi kuota API jika `GEMINI_API_KEY` dipasang di situs publik. **Untuk publik tanpa autentikasi dan rate limit persisten, sebaiknya biarkan `GEMINI_API_KEY` kosong.** Fitur penjelasan berbasis aturan tetap aktif.
- Netlify Functions bersifat serverless; penguncian API, batas request persisten, dan kemampuan historis jangka panjang perlu desain tambahan bila aplikasi menjadi publik dengan trafik tinggi.
- Data market dari penyedia gratis memiliki ketentuan lisensi dan hak redistribution. Pastikan lisensinya mengizinkan penggunaan dan penayangan publik sebelum mengaktifkan LIVE untuk pengguna umum.
- Live crypto pada API publik hanya menyediakan histori pendek, sehingga EMA periode panjang dapat tidak tersedia. UI seharusnya menunjukkan keterbatasan data, bukan menyimpulkan angka baru.
- Versi ini PWA, bukan APK/IPA native. UI statis dapat terbuka dari cache, tetapi data dan penjelasan tetap membutuhkan koneksi internet.

Uji Netlify Functions lokal tanpa Netlify CLI: `npm test`. Untuk preview penuh Netlify via CLI, gunakan `netlify dev` jika CLI telah terpasang (CLI opsional).

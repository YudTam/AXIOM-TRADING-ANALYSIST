# Codex project instructions — AXIOM Market Intelligence

1. This is a zero-cost educational market research application. No subscriptions, paid APIs, or database.
2. Preserve `node server.js` and `npm test` compatibility; avoid dependencies unless crucial and confirmed free.
3. Read README.md and docs/PRD.md before editing.
4. Never fabricate live market data; mark demo distinctly and fail closed on live API error.
5. No broker integration, execution of trades, or guaranteed predictions.
6. Support/resistance algorithm must use confirmed pivots and avoid look-ahead bias.
7. Gemini is OPTIONAL. When unavailable, use clearly identified local-rule explanations; never call local rules 'AI'.
8. Do not hardcode API keys. Never expose server credentials to browser.
9. Follow provider licensing, API throttling, timestamps, and attribution requirements.
10. Always run `npm test` after changing calculations and validate UI paths.
11. Prioritize a clean responsive interface and explainable market analysis.
12. Fundamentals must use verified sources and include provenance, period, release and availability time; otherwise show unavailable.

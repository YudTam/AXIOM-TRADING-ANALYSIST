export const instruments=[
 {id:'BTCUSD',symbol:'BTC/USD',name:'Bitcoin',type:'crypto',providerSymbol:'BTC/USD',coinId:'bitcoin'},
 {id:'ETHUSD',symbol:'ETH/USD',name:'Ethereum',type:'crypto',providerSymbol:'ETH/USD',coinId:'ethereum'},
 {id:'SOLUSD',symbol:'SOL/USD',name:'Solana',type:'crypto',providerSymbol:'SOL/USD',coinId:'solana'},
 {id:'EURUSD',symbol:'EUR/USD',name:'Euro / US Dollar',type:'forex',providerSymbol:'EUR/USD'},
 {id:'GBPUSD',symbol:'GBP/USD',name:'Pound / US Dollar',type:'forex',providerSymbol:'GBP/USD'},
 {id:'USDJPY',symbol:'USD/JPY',name:'US Dollar / Yen',type:'forex',providerSymbol:'USD/JPY'},
 {id:'AAPL',symbol:'AAPL',name:'Apple Inc.',type:'stocks',providerSymbol:'AAPL'},
 {id:'MSFT',symbol:'MSFT',name:'Microsoft',type:'stocks',providerSymbol:'MSFT'},
 {id:'GOOGL',symbol:'GOOGL',name:'Alphabet Inc.',type:'stocks',providerSymbol:'GOOGL'}
];
export const getInstrument=id=>instruments.find(a=>a.id===id);
const hash=s=>[...s].reduce((a,c)=>(Math.imul(a,31)+c.charCodeAt(0))>>>0,1749);
const seeded=seed=>()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};
export function makeDemoCandles(id='BTCUSD',tf='1d',count=260){
 const asset=getInstrument(id);if(!asset)throw Error('Unknown instrument');
 const baseline=({BTCUSD:72000,ETHUSD:3500,SOLUSD:150,EURUSD:1.08,GBPUSD:1.3,USDJPY:149,AAPL:220,MSFT:470,GOOGL:195})[id];
 const step=({'1h':3600,'4h':14400,'1d':86400,'1w':604800})[tf];if(!step)throw Error('Bad timeframe');
 const rnd=seeded(hash(id+tf)),vol=asset.type==='crypto'?.027:asset.type==='forex'?.004:.015;
 const now=Math.floor(Date.now()/step)*step, out=[];let price=baseline*.86;
 for(let i=0;i<count;i++){
  const open=price,cycle=Math.sin((i/33)+hash(id)%7)*vol*.28, shock=(rnd()-.485)*vol*1.7;
  const close=Math.max(.00001,open*(1+shock+cycle+.00045));
  const high=Math.max(open,close)*(1+rnd()*vol*.45),low=Math.min(open,close)*(1-rnd()*vol*.45);
  out.push({time:now-(count-i)*step,open:+open.toFixed(6),high:+high.toFixed(6),low:+low.toFixed(6),close:+close.toFixed(6),volume:asset.type==='forex'?null:Math.round((800000+rnd()*1800000)*(asset.type==='crypto'?20:1))});price=close;
 }return out;
}
export function validateCandles(candles){
 const out=candles.map(c=>({time:Number(c.time),open:Number(c.open),high:Number(c.high),low:Number(c.low),close:Number(c.close),volume:c.volume==null?null:Number(c.volume)}));
 for(const c of out){if(!Number.isSafeInteger(c.time)||![c.open,c.high,c.low,c.close].every(x=>Number.isFinite(x)&&x>0)||c.high<Math.max(c.open,c.close)||c.low>Math.min(c.open,c.close)||c.low>c.high)throw Error('Invalid OHLC data');}
 out.sort((a,b)=>a.time-b.time);if(out.some((c,i)=>i&&c.time===out[i-1].time))throw Error('Duplicate candle timestamp');return out;
}
export function candlesFromTwelve(values,tf){
 const period=({'1h':3600,'4h':14400,'1d':86400,'1w':604800})[tf];
 return validateCandles(values.map(c=>({time:Math.floor(Date.parse(c.datetime.endsWith('Z')?c.datetime:c.datetime.replace(' ','T')+'Z')/1000),open:Number(c.open),high:Number(c.high),low:Number(c.low),close:Number(c.close),volume:c.volume==null?null:Number(c.volume)})));
}

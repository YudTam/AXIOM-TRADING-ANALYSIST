const round=(n,d=5)=>Number.isFinite(n)?+n.toFixed(d):null;
export function ema(values,period){
 const result=Array(values.length).fill(null);if(values.length<period)return result;
 let seed=0;for(let i=0;i<period;i++)seed+=values[i];result[period-1]=seed/period;
 const k=2/(period+1);for(let i=period;i<values.length;i++)result[i]=values[i]*k+result[i-1]*(1-k);return result;
}
export function rsi(values,period=14){
 const out=Array(values.length).fill(null);if(values.length<=period)return out;
 let up=0,down=0;for(let i=1;i<=period;i++){const d=values[i]-values[i-1];if(d>0)up+=d;else down-=d;}
 let avgUp=up/period,avgDown=down/period;out[period]=avgDown===0?(avgUp===0?50:100):100-100/(1+avgUp/avgDown);
 for(let i=period+1;i<values.length;i++){const d=values[i]-values[i-1];avgUp=(avgUp*(period-1)+Math.max(d,0))/period;avgDown=(avgDown*(period-1)+Math.max(-d,0))/period;out[i]=avgDown===0?(avgUp===0?50:100):100-100/(1+avgUp/avgDown);}
 return out;
}
export function atr(candles,period=14){const trueRanges=candles.map((c,i)=>i===0?c.high-c.low:Math.max(c.high-c.low,Math.abs(c.high-candles[i-1].close),Math.abs(c.low-candles[i-1].close)));
 const out=Array(candles.length).fill(null);if(candles.length<period)return out;let sum=0;for(let i=0;i<period;i++)sum+=trueRanges[i];out[period-1]=sum/period;for(let i=period;i<candles.length;i++)out[i]=(out[i-1]*(period-1)+trueRanges[i])/period;return out;}
export function macd(values){
 const f=ema(values,12),s=ema(values,26),line=values.map((_,i)=>f[i]===null||s[i]===null?null:f[i]-s[i]);
 const avail=line.filter(x=>x!==null),sig=ema(avail,9);let k=0;const signal=line.map(x=>x===null?null:sig[k++]);
 return {line,signal,histogram:line.map((x,i)=>x===null||signal[i]===null?null:x-signal[i])};
}
export function findZones(candles,{pivot=5,maxZones=4}={}){
 const A=atr(candles,14),points=[];
 // Confirmed pivot: it is only known after `pivot` later candles exist.
 for(let i=pivot;i<candles.length-pivot;i++){
  let high=true,low=true;
  for(let j=i-pivot;j<=i+pivot;j++){if(j===i)continue;if(candles[j].high>=candles[i].high)high=false;if(candles[j].low<=candles[i].low)low=false;}
  if(high)points.push({type:'resistance',price:candles[i].high,index:i});
  if(low)points.push({type:'support',price:candles[i].low,index:i});
 }
 const last=candles.at(-1),threshold=Math.max((A.at(-1)||last.close*.01)*.65,last.close*.0015);
 const clustered=[];
 for(const p of points){let z=clustered.find(z=>z.type===p.type&&Math.abs(z.price-p.price)<=threshold);if(z){z.price=(z.price*z.touches+p.price)/(z.touches+1);z.touches++;z.lastIndex=Math.max(z.lastIndex,p.index)}else clustered.push({...p,touches:1,lastIndex:p.index});}
 // Classify zones by current price, not by whether they were previously pivot highs or lows.
 const below=clustered.filter(z=>z.price<last.close).map(z=>({...z,score:z.touches+z.lastIndex/candles.length}));
 const above=clustered.filter(z=>z.price>last.close).map(z=>({...z,score:z.touches+z.lastIndex/candles.length}));
 below.sort((a,b)=>b.price-a.price);above.sort((a,b)=>a.price-b.price);
 const format=z=>({price:round(z.price,6),touches:z.touches,score:round(z.score,2),width:round(threshold,6),confirmedAt:candles[Math.min(candles.length-1,z.lastIndex+pivot)].time});
 return {support:below.slice(0,maxZones).map(format),resistance:above.slice(0,maxZones).map(format),all:clustered.length,threshold:round(threshold,6)};
}
export function analyze(candles){
 const closes=candles.map(c=>c.close),last=closes.at(-1),e20=ema(closes,20),e50=ema(closes,50),e200=ema(closes,200),rs=rsi(closes),at=atr(candles),m=macd(closes),z=findZones(candles);
 const current50=e50.at(-1),current200=e200.at(-1),trend=current50==null||current200==null?'insufficient_data':last>current50&&current50>current200?'bullish':last<current50&&current50<current200?'bearish':'mixed';
 const delta=closes.length>=2?(last/closes.at(-2)-1)*100:0;
 const currentATR=at.at(-1);
 return {close:round(last,6),change:round(delta,2),trend,rsi:round(rs.at(-1),2),ema20:round(e20.at(-1),6),ema50:round(current50,6),ema200:round(current200,6),atr:round(currentATR,6),atrPct:currentATR?round(currentATR/last*100,2):null,macd:round(m.line.at(-1),6),macdSignal:round(m.signal.at(-1),6),macdHistogram:round(m.histogram.at(-1),6),support:z.support,resistance:z.resistance,zoneMethod:'Confirmed 5-candle pivots clustered by ATR',fundamental:{status:'not_connected',message:'Data fundamental terverifikasi belum terhubung. Fundamental tidak dinilai otomatis.'},scenarios:{bullish:'Kelanjutan tren naik memerlukan konfirmasi struktur harga dan penutupan di atas zona resistance relevan.',bearish:'Penurunan berlanjut jika harga melemah di bawah support yang terkonfirmasi.',sideways:'Rentang konsolidasi berpotensi berlanjut jika support dan resistance tetap bertahan.'},candleCount:candles.length};
}
export function explainFallback(a){
 const trend=a.trend==='bullish'?'cenderung naik':a.trend==='bearish'?'cenderung turun':'belum menunjukkan tren yang kuat';
 const price=x=>Number(x.price).toLocaleString('en-US',{maximumFractionDigits:6});
 const level=a.support?.length?price(a.support[0]):'belum tersedia',upper=a.resistance?.length?price(a.resistance[0]):'belum tersedia';
 return `RINGKASAN — ${a.symbol} (${a.timeframe}): kondisi teknikal ${trend}. ${a.mode==='demo'?'Ini adalah data simulasi dan bukan harga pasar aktual.':'Analisis hanya berlaku untuk snapshot harga yang digunakan.'}\n\nTEKNIKAL & S/R — RSI: ${a.rsi??'N/A'}, ATR terhadap harga: ${a.atrPct??'N/A'}%. Support terdekat: ${level}; resistance terdekat: ${upper}. Zona berasal dari pivot candle yang telah terkonfirmasi dan pengelompokan berdasarkan ATR.\n\nSKENARIO — Bullish memerlukan konfirmasi kelanjutan tren dan penembusan resistance. Bearish menjadi lebih relevan jika support ditembus. Sideways mungkin terjadi bila harga tetap berada di antara kedua zona. Ini bukan probabilitas atau rekomendasi transaksi.\n\nKETERBATASAN — Fundamental belum terhubung dan kekuatan prediksi belum dibuktikan lewat backtesting. Perhatikan waktu data dan perubahan volatilitas.`;
}

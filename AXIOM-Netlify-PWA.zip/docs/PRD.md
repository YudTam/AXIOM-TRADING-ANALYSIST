# PRD — Market Intelligence Terminal MVP 1.0

## Goals
A zero-required-cost, no-database market dashboard for three asset classes with clearly labeled data, accurate deterministic technical calculations, confirmed-pivot support/resistance zones, 3 conditional scenarios, and optional AI explanation.

## MVP features
- Nine pilot symbols across Crypto, Forex, US Stocks.
- Searchable symbol selector, type filters, 1h/4h/1d/1w timeframes.
- Native-SVG candlestick charts with three EMA overlays and S/R zones.
- RSI 14, MACD 12/26/9, ATR 14, EMA 20/50/200.
- Technical trend classification, conditional scenarios.
- Optional Twelve Data/CoinGecko price data and Gemini explanations.
- Honest fundamental availability indicator and limited live crypto market metrics / optional equity overview; unavailable on other cases.

## Not in scope
Database, accounts, persistent reports, trading execution, guaranteed forecasting, backtesting, economic calendar, realtime streaming.

## Key acceptance criteria
- Works with `node server.js`, no npm install, no API key.
- Demo mode unmistakably marked simulated.
- Invalid OHLC rejected.
- No silently simulated response for failing live data.
- API keys stay server side.
- S/R uses right-side confirmation and appropriate time information.
- Technical tests pass.

## Roadmap
1. Done: demo interactive chart and technical engine.
2. Next: verified fundamentals integration (FRED for macro; stock financials; crypto metrics).
3. Next: test with provider live data and document provider coverage / license.
4. Next: mobile UX refinements, backtesting and data-vintage controls.

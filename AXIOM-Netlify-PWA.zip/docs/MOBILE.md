# AXIOM Mobile PWA

- Manifest: `/manifest.webmanifest`
- Service Worker: `/sw.js`; hanya cache static assets, API tidak dicache
- Icons: 180, 192, 512 PNG
- Requires HTTPS (or localhost secure context) for service worker and installability
- iOS: Safari > Share > Add to Home Screen
- Android: Chrome > menu > Install app / Add to Home Screen
- On same LAN, access computer IP on port 3000 for browser testing.
- For personal deployment prefer HTTPS Node-compatible host, secrets stored server-side. Do not publish the current development server directly.
